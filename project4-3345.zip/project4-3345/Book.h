#ifndef BOOK_H
#define BOOK_H

#include <string>
#include <iostream>

using namespace std;

class Book {
    private:
        string isbn;
        string title;
        string authorLastName;

    public:
        Book() {
        }

        // constructor for the book
        // O(1)
        Book(string bookNum, string bookTitle, string authorName) {
            isbn = bookNum;
            title = bookTitle;
            authorLastName = authorName;
        }

        // getters only
        // O(1)
        string getISBN() {
            return isbn;
        }

        string getTitle() {
            return title;
        }

        string getAuthorLastName() {
            return authorLastName;
        }
        
};
#endif
