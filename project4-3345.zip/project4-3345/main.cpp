#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>


#include "./AVLTree.h"
#include "./AVLNode.h"
#include "./Book.h"

using namespace std;

vector<Book> readFile(fstream&);
void insertBooks(vector<Book>);
void createRBTRandomly(vector<Book>);
string findMin(vector<Book>);
string findMax(vector<Book>);

int main() {
    vector<Book> freshBookList;
    fstream inFile;
    
    inFile.open("./books.txt"); // open a file
    freshBookList = readFile(inFile); // read file and load it into a vector
    inFile.close(); // close the file

    insertBooks(freshBookList); // create the AVL for part 1

    createRBTRandomly(freshBookList); // create an unorganized tree for part 2
}


vector<Book> readFile(fstream& myBooks) { // runs O(N)
    string line = "";
    string word = "";

    string isbn;
    string title = "";
    string author = "";

    int bookItemCounter = 0;

    if (myBooks.is_open()) { // if file is ready to read
        vector<Book> bookList; // init a vector for books
        while(getline(myBooks, line)) { // grab a line
            stringstream lineS(line);
            while(getline(lineS, word, ' ')) { // break the line into. . .
                switch (bookItemCounter) {
                    case 0: // . . . isbn
                        isbn = word;
                        bookItemCounter++;    
                        break;
                    case 1: // . . . title
                        title = word;
                        bookItemCounter++;
                        break;
                    case 2: // . . . and author
                        author = word;
                        break;
                    default:
                        break;
                }
            }
            Book newBook = Book(isbn, title, author); // store all that in a book object
            bookList.push_back(newBook); // push it to the vector
            bookItemCounter = 0; 
        }
        return bookList; // return the vector after all lines are read
    } else {
        cout << "Unable to open file, make sure working directory is '~/path/to/partOne'" << endl;
    }
}

// function runs O(N) * O(1) = O(N)
void insertBooks(vector<Book> books) {
    AVLTree bookTree; // init an avl tree
    
    // for loop runs O(N)
    for (int i = 0; i < books.size(); i++) { // loop through the vector of books
        bookTree.insert(books[i]); // and properly insert it into the tree
    }
    bookTree.display(); // displays the tree inorder
    cout << "AVL tree completed" << endl << endl;
}

// worst case runtime is O(N^2logN)
// fill a random binary tree
void createRBTRandomly(vector<Book> books) {
    cout << "Creating an RBT" << endl;
    AVLTree unorganizedTree; // init an avl tree
    
    // for loop runs O(N)
    for (int i = 0; i < books.size(); i++) { // loop through the vector of books
        unorganizedTree.insertWithoutOrganization(books[i]); // and properly insert it into the tree
    }

    // runtime is O(N)
    bool balanced = unorganizedTree.isBalanced(); // check if tree is balanced
    
    // runtime is O(n) * O(n) * O(logN) = O(N^2logN)
    bool bSTSearchable = unorganizedTree.isBinarySearchable(findMin(books), findMax(books)); // check if tree is searchable through divide and conquer
    
    if (balanced) {
        cout << "Tree is balanced" << endl;
    } else {
        cout << "Tree is NOT balanced" << endl;
    }

    if (bSTSearchable) {
        cout << "Tree is searchable" << endl;
    } else {
        cout << "Tree is NOT searchable" << endl;
    }

    if (balanced && bSTSearchable) {
        cout << "Tree is an AVL tree" << endl;
    } else {
        cout << "Tree is NOT an AVL tree" << endl;
    }

    cout << "Heres the tree inorder" << endl;
    unorganizedTree.display(); // dispaly tree in order
}

// for loop runs O(N)
string findMin(vector<Book> books) { // find min key of entire vector of books
    string min = "99999999999999999999";
    for(int i = 0; i < books.size(); i++) {
        if (books[i].getISBN() < min) {
            min = books[i].getISBN();
        }
    }
    return min;
}

// for loop runs O(N)
string findMax(vector<Book> books) { // find max key of entire vector of books
    string max = "0";
    for(int i = 0; i < books.size(); i++) {
        if (books[i].getISBN() > max) {
            max = books[i].getISBN();
        }
    }
    return max;
}


