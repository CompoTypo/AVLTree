#ifndef AVLNODE_H
#define AVLNODE_H

#include <iostream>
#include <string>
#include "./Book.h"

using namespace std;

class AVLNode {
    private:
        string key;
        Book value;
        int height;
        AVLNode* leftPtr;
        AVLNode* rightPtr;
    public:
        // AVLNode constructor
        // O(1)
        AVLNode(Book book) {
            key = book.getISBN();
            value = book;
            height = 0;
            leftPtr = NULL;
            rightPtr = NULL;
        }

        // Getters and setters below
        // O(1) for all
        string getKey() {
            return key;
        }

        Book getValue() {
            return value;
        }

        int getHeight() {
            if (this == NULL) {
                return -1;
            } else {
                return height;
            }
        }

        AVLNode* getLeftPtr() {
            return leftPtr;
        }

        AVLNode* getRightPtr() {
            return rightPtr;
        }

        void setData(Book bookData) {
            value = bookData;
        }

        void setHeight(int newHeight) {
            height = newHeight;
        }

        void setLeftPtr(AVLNode* left) {
            leftPtr = left;
        }

        void setRightPtr(AVLNode* right) {
            rightPtr = right;
        }
};
#endif